import React, { useEffect, useState, useRef } from "react";

/*
 Simple Study Organizer App (single-file)
 - Login asks only for name (saved to localStorage)
 - Owner: Hemadry Argha (displayed)
 - Save/import/export data using localStorage and JSON export
 - Tailwind CSS used for styling
*/

const LS_KEY = "study_org_vite_v1";
const USER_KEY = "study_user_v1";

const DEFAULT_SUBJECTS = [
  "Engineering - Physics",
  "Engineering - Chemistry",
  "Engineering - Math",
  "Udvash",
  "Acs",
  "Exam Qn"
];

const uid = () => Math.random().toString(36).slice(2,9);
const nowISO = () => new Date().toISOString();

function FileToBase64(file) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result);
    r.onerror = rej;
    r.readAsDataURL(file);
  });
}

export default function App(){
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem(USER_KEY)); } catch { return null; }
  });
  const [data, setData] = useState(() => {
    try { const raw = localStorage.getItem(LS_KEY); if(raw) return JSON.parse(raw); }
    catch(e){}
    return {
      subjects: DEFAULT_SUBJECTS.map(s => ({ id: uid(), name: s })),
      materials: [],
      todos: [],
      prefs: { dark: false }
    };
  });
  const [activeSubject, setActiveSubject] = useState(data.subjects[0]?.id || null);
  const [q, setQ] = useState("");
  const fileRef = useRef();

  useEffect(() => {
    localStorage.setItem(LS_KEY, JSON.stringify(data));
  }, [data]);

  function login(name){
    if(!name) return;
    const u = { name, joined: nowISO() };
    localStorage.setItem(USER_KEY, JSON.stringify(u));
    setUser(u);
  }
  function logout(){
    if(confirm("Logout?")) {
      localStorage.removeItem(USER_KEY);
      setUser(null);
    }
  }

  function addNote(title, content){
    const m = { id: uid(), subjectId: activeSubject, type: "note", title: title || "Note", content, tags: [], createdAt: nowISO() };
    setData(d => ({ ...d, materials: [m, ...d.materials] }));
  }
  async function addFile(file){
    const b64 = await FileToBase64(file);
    const m = { id: uid(), subjectId: activeSubject, type: "file", title: file.name, filename: file.name, content: b64, tags: [], createdAt: nowISO() };
    setData(d => ({ ...d, materials: [m, ...d.materials] }));
  }
  function addLink(link, title){
    const m = { id: uid(), subjectId: activeSubject, type: "link", title: title||link, link, tags: [], createdAt: nowISO() };
    setData(d => ({ ...d, materials: [m, ...d.materials] }));
  }

  function addTodo(text){
    const t = { id: uid(), text, done:false };
    setData(d => ({ ...d, todos: [t, ...d.todos] }));
  }
  function toggleTodo(id){
    setData(d => ({ ...d, todos: d.todos.map(t => t.id===id?{...t, done: !t.done}:t) }));
  }

  function exportAll(){
    const blob = new Blob([JSON.stringify(data,null,2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `study-org-export-${new Date().toISOString().slice(0,10)}.json`; a.click();
    URL.revokeObjectURL(url);
  }
  function importAll(file){
    const r = new FileReader();
    r.onload = () => {
      try { const imported = JSON.parse(r.result); setData(imported); alert("Imported"); } catch(e){ alert("Invalid file"); }
    };
    r.readAsText(file);
  }

  const materialsForActive = data.materials.filter(m => m.subjectId === activeSubject);
  const visibleMaterials = materialsForActive.filter(m => !q ? true : (m.title||"").toLowerCase().includes(q.toLowerCase()));

  if(!user){
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-100 to-pink-100 p-6">
        <div className="bg-white rounded-2xl shadow p-8 w-full max-w-md text-center">
          <h1 className="text-2xl font-bold mb-2 text-indigo-600">Study Organizer</h1>
          <p className="text-gray-600 mb-4">Enter your name to continue</p>
          <input id="name" placeholder="Your name" className="w-full p-3 rounded border mb-4" />
          <button className="w-full py-3 bg-indigo-600 text-white rounded" onClick={() => { const v = document.getElementById('name').value.trim(); if(v) login(v); }}>Continue</button>
          <p className="text-sm text-gray-500 mt-4">Owner: <strong>Hemadry Argha</strong></p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-pink-50 p-6">
      <div className="max-w-7xl mx-auto">
        <header className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-pink-500">Study Organizer</h1>
            <p className="text-sm text-gray-600">Hello, {user.name}! | Owner: Hemadry Argha</p>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={exportAll} className="px-3 py-2 bg-indigo-100 rounded">Export</button>
            <label className="px-3 py-2 bg-green-100 rounded cursor-pointer">
              Import
              <input type="file" accept="application/json" onChange={(e)=>importAll(e.target.files[0])} className="hidden" />
            </label>
            <button onClick={logout} className="px-3 py-2 bg-red-100 rounded">Logout</button>
          </div>
        </header>

        <main className="grid grid-cols-12 gap-6">
          <aside className="col-span-3 bg-white p-4 rounded-2xl shadow">
            <h2 className="font-semibold mb-2">Subjects</h2>
            <div className="space-y-2">
              {data.subjects.map(s => (
                <div key={s.id} className={`p-2 rounded cursor-pointer ${s.id===activeSubject? 'bg-indigo-50': 'hover:bg-gray-100'}`} onClick={()=>setActiveSubject(s.id)}>
                  {s.name}
                </div>
              ))}
            </div>

            <hr className="my-4" />
            <h3 className="font-semibold">Todos</h3>
            <div className="mt-2">
              <input id="todo" placeholder="New todo" className="w-full p-2 rounded border mb-2" />
              <button className="w-full py-2 bg-green-300 rounded" onClick={()=>{ const v = document.getElementById('todo').value.trim(); if(v){ addTodo(v); document.getElementById('todo').value=''; } }}>Add</button>
            </div>
            <div className="mt-3 space-y-2">
              {data.todos.map(t => (
                <div key={t.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <label className="flex items-center gap-2">
                    <input type="checkbox" checked={t.done} onChange={()=>toggleTodo(t.id)} />
                    <span className={t.done? 'line-through text-gray-400': ''}>{t.text}</span>
                  </label>
                </div>
              ))}
            </div>
          </aside>

          <section className="col-span-6 bg-white p-4 rounded-2xl shadow">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold">{data.subjects.find(s=>s.id===activeSubject)?.name}</h2>
              <div>
                <input placeholder="Search..." value={q} onChange={(e)=>setQ(e.target.value)} className="p-2 rounded border" />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {visibleMaterials.map(m => (
                <div key={m.id} className="p-3 rounded border bg-white">
                  <div className="flex justify-between">
                    <strong>{m.title}</strong>
                    <span className="text-xs text-gray-500">{new Date(m.createdAt).toLocaleString()}</span>
                  </div>
                  <p className="text-sm mt-2">{m.type==='note' ? m.content : (m.type==='link' ? m.link : m.filename)}</p>
                  <div className="mt-3 flex gap-2">
                    {m.type==='file' && <a href={m.content} download={m.filename} className="text-sm text-indigo-600">Download</a>}
                    {m.type==='link' && <a href={m.link} target="_blank" rel="noreferrer" className="text-sm text-indigo-600">Open</a>}
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-6">
              <h3 className="font-semibold mb-2">Add material</h3>
              <div className="grid grid-cols-1 gap-2">
                <input id="matTitle" placeholder="Title" className="p-2 rounded border" />
                <textarea id="matNote" placeholder="Note (for note type)" className="p-2 rounded border" />
                <div className="flex gap-2">
                  <label className="px-3 py-2 bg-yellow-100 rounded cursor-pointer">
                    Upload File
                    <input ref={fileRef} type="file" className="hidden" onChange={(e)=>{ const f = e.target.files[0]; if(f) addFile(f); e.target.value=null; }} />
                  </label>
                  <input id="matLink" placeholder="Link (optional)" className="p-2 rounded border flex-1" />
                  <button className="px-3 py-2 bg-indigo-600 text-white rounded" onClick={()=>{ const t = document.getElementById('matTitle').value.trim(); const n = document.getElementById('matNote').value.trim(); const l = document.getElementById('matLink').value.trim(); if(l) addLink(l,t||l); else if(n) addNote(t,n); else alert('Add note text or link or upload file'); document.getElementById('matTitle').value=''; document.getElementById('matNote').value=''; document.getElementById('matLink').value=''; }}>Add</button>
                </div>
              </div>
            </div>
          </section>

          <aside className="col-span-3 bg-white p-4 rounded-2xl shadow">
            <h3 className="font-semibold">Overview</h3>
            <div className="mt-3 space-y-2 text-sm text-gray-600">
              <div>Subjects: {data.subjects.length}</div>
              <div>Total materials: {data.materials.length}</div>
              <div>Notes: {data.materials.filter(m=>m.type==='note').length}</div>
              <div>Files: {data.materials.filter(m=>m.type==='file').length}</div>
              <div>Links: {data.materials.filter(m=>m.type==='link').length}</div>
            </div>
            <hr className="my-4" />
            <p className="text-xs text-gray-500">Tip: Export backup before publishing. Files are stored in browser storage as base64.</p>
          </aside>
        </main>

        <footer className="text-center text-sm text-gray-500 mt-6">© {new Date().getFullYear()} Hemadry Argha</footer>
      </div>
    </div>
  );
}
