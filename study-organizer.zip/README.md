# Study Organizer

A lightweight Study Organizer (Vite + React + Tailwind) that stores materials locally and includes a simple name-only login.

## Quick start (locally)

1. Install dependencies:
```
npm install
```

2. Start dev server:
```
npm run dev
```

3. Open the URL shown by Vite (usually http://localhost:5173)

## Deploy to Vercel / Netlify

- Vercel: `npm run build` is run automatically; set framework to `Vite` if prompted.
- Netlify: set build command `npm run build` and publish directory `dist`.

## Notes

- Login asks only for a name and stores it in browser localStorage.
- Files uploaded are stored as base64 in localStorage — export your data before clearing browser storage.
- Owner/author: **Hemadry Argha**

